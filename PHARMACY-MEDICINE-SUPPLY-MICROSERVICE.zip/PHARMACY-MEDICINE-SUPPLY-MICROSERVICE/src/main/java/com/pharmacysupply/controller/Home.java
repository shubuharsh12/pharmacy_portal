//package com.pharmacysupply.controller;
//
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class Home {
//    @RequestMapping("/PharmacySupply/")
//    public String medicinestock()
//    {
//        String text= "this is private page";
//        return  text;
//    }
//}